<footer class="footer">
        <p>&copy; Company 2017</p>
      </footer>
