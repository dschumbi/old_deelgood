@extends('layouts.cover') @section('content')
<h2>Vielen Dank für Ihre Anfrage</h2>
<p>
    Da Sie noch nicht registriert sind, bitten wir Sie, Ihre Anfrage zu bestätigen. In dem Postfach der angegebenen Mail-Adresse finden Sie eine E-Mail mit einem Bestätigungslink. Nachdem Sie durch anklicken des Bestätigungslinks Ihre Anfrage aktiviert haben, werden Händler aus Ihrem Umkreis über Ihr Anliegen informiert und können Angebote abgeben.
</p>
<p>
    Sie können jederzeit weitere Anfragen über unsere Plattform stellen!
</p>
@endsection @section('footer')
<script src="/js/file.js"></script>
@endsection
