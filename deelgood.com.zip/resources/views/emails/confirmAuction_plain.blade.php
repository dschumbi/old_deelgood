== Bitte bestätigen Sie Ihre Anfrage ==
{{ $auction->name }}

{{ $auction->auctionToken }}
