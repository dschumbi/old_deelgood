<?php

namespace App;

class Trader extends Model
{
    protected $fillable = [
        'name', 'street', 'zip', 'city'
    ];
}
