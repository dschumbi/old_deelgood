<?php $__env->startComponent('mail::message'); ?>
# Bitte bestätigen Sie Ihre Anfrage

Vielen Dank für Ihre Anfrage __<?php echo e($auction->name); ?>__

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/auctions/confirmAuction/'.$auction->auctionToken]); ?>
Anfrage bestätigen
<?php echo $__env->renderComponent(); ?>

Vielen Dank,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
