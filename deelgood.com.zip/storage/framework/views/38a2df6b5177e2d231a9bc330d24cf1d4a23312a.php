<header class="header clearfix">
        <nav>
        <ul class="nav nav-pills float-right">
          <li class="nav-item">
            <a class="nav-link" href="/">Home</a>
          </li>
          <?php if(auth()->guard()->guest()): ?>
              <div class="nav-item">
                <li><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
              </div>
              <div class="nav-item">
                <li><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
              </div>
          <?php else: ?>
              <li class="nav-item">
                <a class="nav-link" href="/auctions">Meine Deels</a>
              </li>
              <li class="nav-item dropdown">
                  <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                      <?php echo e(Auth::user()->firstname .' '. Auth::user()->name); ?> <span class="caret"></span>
                  </a>

                  <ul class="dropdown-menu" role="menu">
                      <li>
                          <a href="<?php echo e(route('logout')); ?>"
                              onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();"
                              class="dropdown-item">
                              Logout
                          </a>

                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo e(csrf_field()); ?>

                          </form>
                      </li>
                      <li>
                        <a href="<?php echo e(route('edit')); ?>"
                            class="dropdown-item">
                            Profil bearbeiten
                        </a>
                      </li>
                  </ul>
              </li>
          <?php endif; ?>
        </ul>
      </nav>
      <a class="navbar-brand" rel="home" href="/" title="Buy Sell Rent Everyting">
          <?php echo e(HTML::image('img/logo_rgb.jpg', 'Deelgood', array('class' => 'img-responsive2', 'style' => 'max-width:160px'))); ?>

      </a>

      </header>

