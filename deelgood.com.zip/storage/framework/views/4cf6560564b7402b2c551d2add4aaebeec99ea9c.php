    <div class="card card-block">
            <h2 class="card-title">Laravel AJAX Examples
                <small>via jQuery .ajax()</small>
            </h2>
            <p class="card-text">Learn how to handle ajax with Laravel and jQuery.</p>
            <button id="btn-add" name="btn-add" class="btn btn-primary btn-xs">Add New Link</button>
        </div>
    <table class="table">
        <thead>
        <tr>
            <th>Name</th>
            <th>Straße</th>
            <th>Edit or Delete</th>
        </tr>
        </thead>
        <tbody id="traders-list" name="traders-list">
        <?php $__currentLoopData = $user->traders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="trader<?php echo e($trader->id); ?>">
                <td><?php echo e($trader->name); ?></td>
                <td><?php echo e($trader->street); ?></td>
                <td>
                    <button class="btn btn-info open-modal" value="<?php echo e($trader->id); ?>">Bearbeiten
                    </button>
                    <button class="btn btn-danger delete-link" value="<?php echo e($trader->id); ?>">Löschen
                    </button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php echo $__env->make('auth.tradersModal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
