 <?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <?php echo e(HTML::image('img/logo_rgb.jpg', 'Deelgood', array('class' => 'img-responsive2 logo', 'style' => 'max-width:400px'))); ?>

    <!-- <p class="lead">Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add your own fullscreen background photo to make it your own.</p> -->
    <form method="POST" action="/auctions/finish" class="form-horizontal">
        <?php echo e(csrf_field()); ?>

        <div class="row justify-content-center">
            <div class="col-8">
                <div class="form-group">
                    <input type="text" class="form-control <?php if($errors->has('name')): ?> is-invalid <?php endif; ?> " id="name" name="name" aria-describedby="nameHelp" placeholder="z.B. ... Waschmaschine für 4 Personen Haushalt"> <?php if($errors->has('name')): ?>
                    <small id="nameHelp" class="invalid-feedback">Was für ein Produkt möchten Sie kaufen?</small> <?php else: ?>
                    <small id="nameHelp" class="form-text text-muted">Was für ein Produkt möchten Sie kaufen?</small> <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="form-group">
                    <input type="hidden" name="auctionToken" id="auctionToken" value="<?php echo e($token); ?>" />
                    <input type="text" class="form-control" id="link" name="link" aria-describedby="linkHelp" placeholder="Link zu einem Online-Shop" data-toggle="tooltip">
                    <small id="linkHelp" class="form-text text-muted">Haben Sie den Artikel in einem Online-Shop gesehen?</small>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="form-group">
                    <button type="submit" class="btn btn-lg btn-primary">Jetzt anfragen!</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php echo $__env->make('auctions.infotext', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('footer'); ?>
<script src="/js/file.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>