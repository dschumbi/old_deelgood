<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <h6>Produktkategorie: <?php echo e($auction->category->name); ?></h6>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <h1><?php echo e($auction->name); ?></h1>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <span class="label label-default">
                Start der Anfrage:
                </span>
                <p>
                    <?php echo e($auction->auction_start->formatLocalized('%d. %B %Y')); ?>

                </p>
            </div>
            <div class="col">
                <span class="label label-default">
                Ende der Anfrage:
                </span>
                <p>
                    <?php echo e($auction->auction_end->formatLocalized('%d. %B %Y')); ?>

                </p>
            </div>
            <div class="col">
                <span class="label label-default">
                Kaufdatum:
                </span>
                <p>
                    <?php echo e($auction->deliveryDate); ?>

                </p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <span class="label label-default">
                Maximaler Preis:
                </span>
                <p>
                    <?php echo e($auction->maxPrice); ?> &euro;
                </p>
            </div>
            <div class="col">
                <span class="label label-default">
                Link zu einem Online-Shop:
                </span>
                <p>
                    <a href="<?php echo e($auction->link); ?>" target="_blank">
                        <?php echo e($auction->link); ?>

                    </a>
                </p>
            </div>
            <div class="col">
                <span class="label label-default">
                Abholung oder Lieferung:
                </span>
                <p>
                    <?php if($auction->pickUpInStore): ?>
                        Abholung
                    <?php else: ?>
                        Lieferung nach Hause
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <hr>
        <h2>Angebot für diese Anfrage erstellen</h2>
        <hr>
        <form method="POST" action="/auctions/<?php echo e($auction->id); ?>/offers">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-4">
                    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                      <a class="nav-link active" id="v-pills-base-tab" data-toggle="pill" href="#v-pills-base" role="tab" aria-controls="v-pills-base" aria-selected="true">Artikelstamm</a>
                      <a class="nav-link" id="v-pills-properties-tab" data-toggle="pill" href="#v-pills-properties" role="tab" aria-controls="v-pills-properties" aria-selected="false">Produkteigenschaften</a>
                      <a class="nav-link" id="v-pills-info-tab" data-toggle="pill" href="#v-pills-info" role="tab" aria-controls="v-pills-info" aria-selected="false">Weitere Informationen</a>
                    </div>
                </div>
                <div class="col-8">
                    <div class="tab-content" id="v-pills-tabContent">
                        <?php echo $__env->make('auctions.offers.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('auctions.offers.properties', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('auctions.offers.additionalInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <hr>
            <div class="form-group row">
              <div class="col-sm-12 text-right">
                <button type="submit" class="btn btn-success">Angebot einreichen</button>
              </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>