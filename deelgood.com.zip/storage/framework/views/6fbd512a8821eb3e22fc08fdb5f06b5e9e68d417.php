<div class="tab-pane fade" id="v-pills-properties" role="tabpanel" aria-labelledby="v-pills-properties-tab">
    <h3>Produkteigenschaften</h3>
    <div class="form-group row">
        <div class="col-12 mb-3">
            <label for="manufacturer">Welche Eigenschaften hat der Artikel? <br>Folgende Produkteigenschaften wünscht sich der Kunde:</label>
        </div>
        <?php $__currentLoopData = $auction->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
                <label><?php echo e(Form::checkbox('properties[]',
                                $property->id,
                                false,
                                ['class' => 'grey','data-id'=> $property->id])); ?>

                    <?php echo e($property->name); ?>

                </label>
                <div class="clearfix"></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
