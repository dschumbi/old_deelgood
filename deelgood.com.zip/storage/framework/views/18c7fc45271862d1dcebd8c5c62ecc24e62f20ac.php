<div class="form-row">

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="form-group">
                <label><?php echo e(Form::checkbox('categories[]',
                                $category->id,
                                in_array($category->id, $checkedResource) ? true : false,
                                ['class' => 'grey','data-id'=> $category->id])); ?>

                    <?php echo e($category->name); ?>

                </label>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="form-row">
  <button type="submit" class="btn btn-primary">
    <i class="fa fa-btn fa-sign-in"></i>Update
  </button>
</div>
