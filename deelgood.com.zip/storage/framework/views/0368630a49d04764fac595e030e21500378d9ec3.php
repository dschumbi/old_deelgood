== Bitte bestätigen Sie Ihre Anfrage ==
<?php echo e($auction->name); ?>


<?php echo e($auction->auctionToken); ?>

