<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-10">

            <div class="d-flex justify-content-between">
              <h5 class="mb-1"><?php echo e($auction->name); ?></h5>
                <small class="text-muted">
                    <?php echo e($auction->created_at->diffForHumans()); ?>

                </small>
            </div>
            <div class="row">
                <div class="col">
                    Anzahl der Angebote: <?php echo e(count($auction->offers)); ?>

                </div>
                <?php if($auction->user): ?>
                <div class="col">
                    Name des Kunden: <?php echo e($auction->user->name); ?>

                </div>
                <?php endif; ?>
                <div class="col">
                    Produktkategorie: <?php echo e($auction->category->name); ?>

                </div>
                <div class="col alert alert-warning" role="alert">
                    Hier Infos über Kategorie, Enddatum etc.
                </div>
            </div>
        </a>
    </div>
    <div class="col-2">
        <a href="/auctions/show/<?php echo e($auction->id); ?>" class="btn btn-primary">Ansehen</a>
        <a href="/auctions/modify/<?php echo e($auction->auctionToken); ?>" class="btn btn-secondary">Bearbeiten</a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>