 <?php $__env->startSection('content'); ?>
<h2>Vielen Dank für Ihre Anfrage</h2>
<p>
    Da Sie noch nicht registriert sind, bitten wir Sie, Ihre Anfrage zu bestätigen. In dem Postfach der angegebenen Mail-Adresse finden Sie eine E-Mail mit einem Bestätigungslink. Nachdem Sie durch anklicken des Bestätigungslinks Ihre Anfrage aktiviert haben, werden Händler aus Ihrem Umkreis über Ihr Anliegen informiert und können Angebote abgeben.
</p>
<p>
    Sie können jederzeit weitere Anfragen über unsere Plattform stellen!
</p>
<p>
    token: <?php echo e($auction->auctionToken); ?>

</p>
<?php $__env->stopSection(); ?> <?php $__env->startSection('footer'); ?>
<script src="/js/file.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>