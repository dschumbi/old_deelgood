<?php $__env->startComponent('mail::message'); ?>
# Übersicht Ihrer Anfragen

Übersicht über Ihre Anfragen bla bla bla

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/auctions/buyer/'.$auction->hash]); ?>
Alle Anfragen ansehen
<?php echo $__env->renderComponent(); ?>

Vielen Dank,<br>
Ihr <?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
