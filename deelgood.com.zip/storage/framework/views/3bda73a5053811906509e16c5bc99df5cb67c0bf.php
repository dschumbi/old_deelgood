<?php $__env->startComponent('mail::message'); ?>
# Neue Anfrage

Es ist eine neue Anfrage eingegangen, die Sie interessieren könnte.

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/auctions/show/'.$auction->auctionToken]); ?>
Anfrage ansehen und Gebot abgeben
<?php echo $__env->renderComponent(); ?>

Vielen Dank,<br>
Ihr <?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
