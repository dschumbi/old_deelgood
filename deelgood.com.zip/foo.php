<?php

namespace App\Test;

class Test
{
    public function myMethod()
    {
        return;
    }
}
